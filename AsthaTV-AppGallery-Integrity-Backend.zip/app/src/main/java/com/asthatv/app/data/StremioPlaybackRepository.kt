package com.asthatv.app.data

import com.asthatv.app.model.StremioStream
import com.asthatv.app.player.PlaybackSource
import com.asthatv.app.player.StremioStreamResolver

/** Fetches Stremio streams concurrently at the ViewModel/repository layer and maps them to playback. */
class StremioPlaybackRepository {
    suspend fun sources(addon: StremioAddonClient, type: String, id: String): List<Pair<StremioStream, PlaybackSource>> =
        addon.streams(type, id).mapNotNull { stream ->
            StremioStreamResolver.resolve(stream)?.let { stream to it }
        }
}

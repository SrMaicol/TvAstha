package com.asthatv.app.data

import com.asthatv.app.model.StremioManifest
import com.asthatv.app.model.StremioStream
import com.asthatv.app.model.StremioSubtitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder

/**
 * Minimal Stremio Addon v3 HTTP client.
 * Network + JSON parsing happen on Dispatchers.IO and never block the Compose thread.
 * Private addon URLs may contain credentials: do not log them.
 */
class StremioAddonClient(manifestUrl: String) {
    private val manifestUri = URI(manifestUrl)
    private val baseUrl: String

    init {
        require(manifestUri.scheme == "https") { "Only HTTPS addon URLs are accepted" }
        require(manifestUri.path.endsWith("/manifest.json")) { "URL must end with /manifest.json" }
        baseUrl = manifestUrl.removeSuffix("/manifest.json").trimEnd('/')
    }

    suspend fun manifest(): StremioManifest = withContext(Dispatchers.IO) {
        val json = getJson("$baseUrl/manifest.json")
        StremioManifest(
            id = json.optString("id"),
            version = json.optString("version"),
            name = json.optString("name"),
            description = json.optString("description"),
            resources = json.optJSONArray("resources").stringValues(),
            types = json.optJSONArray("types").stringValues()
        )
    }

    suspend fun catalog(type: String, id: String, extra: Map<String, String> = emptyMap()): JSONObject =
        withContext(Dispatchers.IO) {
            val suffix = if (extra.isEmpty()) "" else {
                "/" + extra.entries.joinToString("&") { (k, v) ->
                    "${enc(k)}=${enc(v)}"
                }
            }
            getJson("$baseUrl/catalog/${enc(type)}/${enc(id)}$suffix.json")
        }

    suspend fun meta(type: String, id: String): JSONObject = withContext(Dispatchers.IO) {
        getJson("$baseUrl/meta/${enc(type)}/${enc(id)}.json")
    }

    suspend fun streams(type: String, id: String): List<StremioStream> = withContext(Dispatchers.IO) {
        val array = getJson("$baseUrl/stream/${enc(type)}/${enc(id)}.json").optJSONArray("streams")
            ?: JSONArray()
        buildList {
            for (i in 0 until array.length()) {
                val s = array.optJSONObject(i) ?: continue
                add(
                    StremioStream(
                        name = s.optString("name").takeIf { it.isNotBlank() },
                        title = s.optString("title").takeIf { it.isNotBlank() },
                        url = s.optString("url").takeIf { it.isNotBlank() },
                        infoHash = s.optString("infoHash").takeIf { it.isNotBlank() },
                        fileIdx = if (s.has("fileIdx")) s.optInt("fileIdx") else null,
                        externalUrl = s.optString("externalUrl").takeIf { it.isNotBlank() }
                    )
                )
            }
        }
    }

    suspend fun subtitles(type: String, id: String): List<StremioSubtitle> = withContext(Dispatchers.IO) {
        val array = getJson("$baseUrl/subtitles/${enc(type)}/${enc(id)}.json").optJSONArray("subtitles")
            ?: JSONArray()
        buildList {
            for (i in 0 until array.length()) {
                val s = array.optJSONObject(i) ?: continue
                val url = s.optString("url")
                if (url.isBlank()) continue
                add(StremioSubtitle(s.optString("id"), url, s.optString("lang")))
            }
        }
    }

    private fun getJson(url: String): JSONObject {
        val connection = URI(url).toURL().openConnection() as HttpURLConnection
        return try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 8_000
            connection.readTimeout = 12_000
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("User-Agent", "AsthaTV/0.1")
            connection.instanceFollowRedirects = true
            val code = connection.responseCode
            if (code !in 200..299) error("Addon returned HTTP $code")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())

    private fun JSONArray?.stringValues(): List<String> {
        if (this == null) return emptyList()
        return buildList {
            for (i in 0 until length()) {
                when (val value = opt(i)) {
                    is String -> add(value)
                    is JSONObject -> value.optString("name").takeIf { it.isNotBlank() }?.let(::add)
                }
            }
        }
    }
}
